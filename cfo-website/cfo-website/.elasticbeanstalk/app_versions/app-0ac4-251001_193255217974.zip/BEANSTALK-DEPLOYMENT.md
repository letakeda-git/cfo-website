# AWS Elastic Beanstalk Deployment Guide

This guide will help you deploy the CFO Website to AWS Elastic Beanstalk.

## Prerequisites

### 1. Install AWS CLI
```bash
# macOS
brew install awscli

# Linux/Windows
pip install awscli
```

### 2. Install EB CLI
```bash
# macOS
brew install awsebcli

# Linux/Windows
pip install awsebcli
```

### 3. Configure AWS CLI
```bash
aws configure
```
Enter your:
- AWS Access Key ID
- AWS Secret Access Key
- Default region: `eu-west-1`
- Default output format: `json`

## Deployment Steps

### 1. Prepare Environment Variables

Create a production environment file:
```bash
cp production.env.example .env.production
```

Edit `.env.production` with your actual values:
- Change `JWT_SECRET` to a secure random string
- Set your AWS credentials (or use IAM roles)

### 2. Deploy to AWS Beanstalk

#### Option A: Using the deployment script
```bash
./deploy-beanstalk.sh
```

#### Option B: Manual deployment
```bash
# Initialize EB application
eb init --platform node.js --region eu-west-1 cfo-website

# Create environment
eb create cfo-website-env --platform "Node.js 18" --instance-type t3.micro

# Set environment variables
eb setenv NODE_ENV=production AWS_REGION=eu-west-1

# Deploy
eb deploy
```

### 3. Configure Environment Variables

Set your production environment variables:
```bash
eb setenv \
  NODE_ENV=production \
  AWS_REGION=eu-west-1 \
  COGNITO_USER_POOL_ID=eu-west-1_XzBjrQrxK \
  COGNITO_CLIENT_ID=7t55ikg2csoqoh93r7bujhe6hc \
  COGNITO_IDENTITY_POOL_ID=eu-west-1:fc3bb5e7-2087-43cc-953b-5caa8d73a7f3 \
  JWT_SECRET=your-secure-jwt-secret \
  AWS_ACCESS_KEY_ID=your-access-key \
  AWS_SECRET_ACCESS_KEY=your-secret-key
```

### 4. Get Application URL
```bash
eb status
```

## Post-Deployment Configuration

### 1. Update CORS Settings
Update your server.js to allow your production domain:
```javascript
app.use(cors({
  origin: ['http://localhost:3000', 'https://your-domain.elasticbeanstalk.com'],
  credentials: true
}));
```

### 2. Configure Custom Domain (Optional)
1. Go to AWS Route 53
2. Create a hosted zone for your domain
3. Create a CNAME record pointing to your EB environment
4. Configure SSL certificate in EB

### 3. Set up IAM Roles (Recommended)
Instead of using AWS credentials in environment variables:

1. Create an IAM role for EC2 instances
2. Attach policies for:
   - DynamoDB access
   - Cognito access
   - SES access (if using email)
3. Assign the role to your EB environment

## Useful Commands

### View Logs
```bash
eb logs
```

### Check Health
```bash
eb health
```

### SSH into Instance
```bash
eb ssh
```

### Update Environment Variables
```bash
eb setenv VARIABLE_NAME=value
```

### Deploy Updates
```bash
eb deploy
```

### Terminate Environment
```bash
eb terminate
```

## Troubleshooting

### Common Issues

1. **Application won't start**
   - Check logs: `eb logs`
   - Verify environment variables are set
   - Check if all dependencies are installed

2. **Database connection issues**
   - Verify AWS credentials
   - Check DynamoDB table permissions
   - Ensure tables exist in the correct region

3. **CORS errors**
   - Update CORS settings in server.js
   - Add your production domain to allowed origins

4. **Environment variables not loading**
   - Use `eb setenv` to set variables
   - Restart the environment: `eb restart`

### Monitoring

1. **CloudWatch Logs**
   - View application logs in CloudWatch
   - Set up log retention policies

2. **Health Monitoring**
   - Use `eb health` to check application status
   - Set up CloudWatch alarms

3. **Performance Monitoring**
   - Monitor CPU and memory usage
   - Set up auto-scaling if needed

## Security Considerations

1. **Environment Variables**
   - Never commit `.env` files to version control
   - Use IAM roles instead of access keys when possible
   - Rotate secrets regularly

2. **HTTPS**
   - Enable HTTPS redirect (already configured)
   - Use AWS Certificate Manager for SSL certificates

3. **Database Security**
   - Use IAM roles for database access
   - Enable encryption at rest
   - Use VPC endpoints for DynamoDB

## Cost Optimization

1. **Instance Types**
   - Start with t3.micro for development
   - Scale up based on usage
   - Use spot instances for non-critical workloads

2. **Auto Scaling**
   - Configure auto-scaling based on CPU/memory
   - Set minimum and maximum instances
   - Use scheduled scaling for predictable traffic

3. **Monitoring**
   - Set up billing alerts
   - Monitor unused resources
   - Use CloudWatch for cost analysis

## Next Steps

1. **Set up monitoring and alerting**
2. **Configure backup strategies**
3. **Set up CI/CD pipeline**
4. **Implement security best practices**
5. **Plan for scaling and high availability**
