document.addEventListener('DOMContentLoaded', () => {
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  // Smooth scroll for same-page anchors
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const href = anchor.getAttribute('href');
      if (!href || href === '#') return;
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Load total players count
  loadTotalPlayers();
});

async function loadTotalPlayers() {
  try {
    // Check if apiClient is available (only works when logged in)
    if (typeof window.apiClient !== 'undefined' && window.apiClient.token) {
      const result = await window.apiClient.getPlayers();
      if (result.success && result.players) {
        const totalPlayers = result.players.length;
        const chartSpark = document.querySelector('.chart-spark');
        if (chartSpark) {
        chartSpark.innerHTML = `
          <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05)); border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.2);">
            <div style="font-size: 16px; color: var(--muted); margin-bottom: 8px; font-weight: 500; text-align: center; width: 100%;">Total de Atletas</div>
            <div style="font-size: 68px; font-weight: 700; color: var(--brand); text-shadow: 0 2px 4px rgba(239, 68, 68, 0.3); text-align: center; width: 100%; margin-top: -30px;">${totalPlayers}</div>
          </div>
        `;
        }
      }
    } else {
      // Show default message when not logged in
      const chartSpark = document.querySelector('.chart-spark');
      if (chartSpark) {
        chartSpark.innerHTML = `
          <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05)); border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.2);">
            <div style="font-size: 16px; color: var(--muted); margin-bottom: 8px; font-weight: 500; text-align: center; width: 100%;">Total de Atletas</div>
            <div style="font-size: 68px; font-weight: 700; color: var(--brand); text-shadow: 0 2px 4px rgba(239, 68, 68, 0.3); text-align: center; width: 100%; margin-top: -30px;">Carregando...</div>
          </div>
        `;
      }
    }
  } catch (error) {
    console.error('Error loading players count:', error);
    const chartSpark = document.querySelector('.chart-spark');
    if (chartSpark) {
      chartSpark.innerHTML = `
        <div style="text-align: center; padding: 20px; background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05)); border-radius: 12px; border: 1px solid rgba(239, 68, 68, 0.2);">
          <div style="font-size: 16px; color: var(--muted); margin-bottom: 8px; font-weight: 500; text-align: center; width: 100%;">Total de Atletas</div>
          <div style="font-size: 68px; font-weight: 700; color: var(--brand); text-shadow: 0 2px 4px rgba(239, 68, 68, 0.3); text-align: center; width: 100%; margin-top: -30px;">N/A</div>
        </div>
      `;
    }
  }
}



