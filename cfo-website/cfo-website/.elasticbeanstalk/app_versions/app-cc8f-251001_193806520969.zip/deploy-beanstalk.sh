#!/bin/bash

# AWS Elastic Beanstalk Deployment Script for CFO Website
# This script deploys the application to AWS Elastic Beanstalk

set -e  # Exit on any error

echo "🚀 Starting AWS Elastic Beanstalk deployment..."

# Check if EB CLI is installed
if ! command -v eb &> /dev/null; then
    echo "❌ AWS EB CLI is not installed. Please install it first:"
    echo "   pip install awsebcli"
    echo "   or"
    echo "   brew install awsebcli"
    exit 1
fi

# Check if AWS CLI is configured
if ! aws sts get-caller-identity &> /dev/null; then
    echo "❌ AWS CLI is not configured. Please run 'aws configure' first."
    exit 1
fi

# Check if .env file exists
if [ ! -f ".env" ]; then
    echo "❌ .env file not found. Please create it with your AWS credentials."
    exit 1
fi

echo "✅ Prerequisites checked"

# Initialize EB application if not already done
if [ ! -d ".elasticbeanstalk" ]; then
    echo "🔧 Initializing Elastic Beanstalk application..."
    eb init --platform node.js --region eu-west-1 cfo-website
fi

# Create environment if it doesn't exist
echo "🌍 Checking for existing environment..."
if ! eb list | grep -q "cfo-website-env"; then
    echo "🔧 Creating new environment..."
    eb create cfo-website-env --platform "Node.js 18" --instance-type t3.micro --region eu-west-1
else
    echo "✅ Environment already exists"
fi

# Set environment variables
echo "🔧 Setting environment variables..."
eb setenv \
    NODE_ENV=production \
    AWS_REGION=eu-west-1 \
    COGNITO_USER_POOL_ID=eu-west-1_XzBjrQrxK \
    COGNITO_CLIENT_ID=7t55ikg2csoqoh93r7bujhe6hc \
    COGNITO_IDENTITY_POOL_ID=eu-west-1:fc3bb5e7-2087-43cc-953b-5caa8d73a7f3 \
    JWT_SECRET=your-jwt-secret-here \
    AWS_ACCESS_KEY_ID=your-access-key \
    AWS_SECRET_ACCESS_KEY=your-secret-key

echo "📦 Deploying application..."
eb deploy

echo "🌐 Getting application URL..."
eb status

echo "✅ Deployment completed!"
echo "🔗 Your application should be available at the URL shown above"
echo ""
echo "📋 Next steps:"
echo "1. Update the environment variables with your actual AWS credentials"
echo "2. Test the application endpoints"
echo "3. Configure custom domain if needed"
echo ""
echo "🔧 Useful commands:"
echo "  eb logs          - View application logs"
echo "  eb health        - Check application health"
echo "  eb ssh            - SSH into the instance"
echo "  eb terminate      - Terminate the environment"
